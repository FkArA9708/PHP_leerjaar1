<?php
// auteur: furkan
// functie: verwijder een categorie op basis van het ID
include 'functions_fietsen.php';
 

if(isset($_GET['id_fietsen'])){
    if (DeleteFietsen($_GET['id_fietsen'])) { 
        echo '<script>alert("Fietsen met ID: ' . $_GET['id_fietsen'] . ' is verwijderd")</script>';
        echo "<script> location.replace('crud_fietsen.php'); </script>";
    }
}
?>