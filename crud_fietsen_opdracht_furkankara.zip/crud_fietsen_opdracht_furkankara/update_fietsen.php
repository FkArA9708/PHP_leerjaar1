<?php
    echo "<h1>Update Fietsen</h1>";
    require_once('functions_fietsen.php');

    if(isset($_POST['btn_wzg'])){
        UpdateFietsen($_POST);
        echo "<script> location.replace('crud_fietsen.php'); </script>";
    }

    if(isset($_GET['id_fietsen'])){  
        $id = $_GET['id_fietsen'];
        $row = GetFietsen($id);
        
        if($row) {
?>

<html>
    <body>
        <form method="post">
        <br>
        <input type="hidden" name="id_fietsen" value="<?php echo htmlspecialchars($row['id_fietsen']);?>"><br> 
        Merk fiets: <input type="text" name="merk_fietsen" value="<?php echo htmlspecialchars($row['merk_fietsen']);?>" required><br>
        <br>
        Type fiets: <input type="text" name="type_fietsen" value="<?php echo htmlspecialchars($row['type_fietsen']);?>" required><br>
        <br>
        Prijs fiets (€): <input type="number" name="prijs_fietsen" step="0.01" min="0" value="<?php echo htmlspecialchars($row['prijs_fietsen']);?>" required><br>
        <br>
        <input type="submit" name="btn_wzg" value="Wijzigen"><br>
        </form>
        <br><br>
        <a href='crud_fietsen.php'>Home</a>
    </body>
</html>

<?php
        } else {
            echo "Error: Geen geldige fiets gevonden.<br>";
            echo "<a href='crud_fietsen.php'>Terug naar overzicht</a>";
        }
    } else {
        echo "Geen fiets ID opgegeven<br>";
        echo "<a href='crud_fietsen.php'>Terug naar overzicht</a>";
    }
?>