<?php
    // functie: Programma CRUD Categorie Nexus
    // Auteur: Furkan Kara

    // Initialisatie
    include 'functions_fietsen.php';

   
    CrudFietsen(); 
?>