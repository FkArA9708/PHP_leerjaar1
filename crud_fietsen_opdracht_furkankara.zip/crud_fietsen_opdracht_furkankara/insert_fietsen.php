<?php
echo "<h1>Insert Fietsen</h1>";

require_once('functions_fietsen.php');

if (isset($_POST['btn_ins'])) {
    if (InsertFietsen($_POST)) {
        echo '<script>alert("Fiets ' . $_POST['merk_fietsen'] . ' is toegevoegd")</script>';
        echo "<script> location.replace('crud_fietsen.php'); </script>";
    }
}
?>

<html>
<body>
<form method="post">
    <br>
    Merk fiets: <input type="text" name="merk_fietsen" required><br>
    <br>
    Type fiets: <input type="text" name="type_fietsen" required><br>
    <br>
    Prijs fiets (€): <input type="number" name="prijs_fietsen" step="0.01" min="0" required><br>
    <br>
    <input type="submit" name="btn_ins" value="Insert"><br>
</form>
<br><br>
<a href='crud_fietsen.php'>Home</a>
</body>
</html>