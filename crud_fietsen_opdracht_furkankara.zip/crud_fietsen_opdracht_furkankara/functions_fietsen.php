<?php
function CrudFietsen() {
    $txt = "
    <h1>Crud Fietsen</h1>
    <nav>
        <a href='insert_fietsen.php'>Toevoegen nieuwe fietsen</a>
    </nav>";

    echo $txt;

    $result = GetData("fietsenshop"); 
    
    if ($result) {
        PrintCrudFietsen($result);
    } else {
        echo "<p>Geen gegevens gevonden.</p>";
    }
}

function PrintCrudFietsen($result) {
    $table = "<table border='1'>";
    
    if (!empty($result)) {
        $headers = array_keys($result[0]);
        $table .= "<tr>";
        foreach ($headers as $header) {
            $table .= "<th bgcolor='gray'>" . htmlspecialchars($header) . "</th>";
        }
        $table .= "<th bgcolor='gray'>Wijzigen</th>";
        $table .= "<th bgcolor='gray'>Verwijderen</th>";
        $table .= "</tr>";

        foreach ($result as $row) {
            $table .= "<tr>";

            foreach ($row as $cell) {
                $table .= "<td>" . htmlspecialchars($cell) . "</td>";
            }

           
            $idField = isset($row['id_fietsen']) ? 'id_fietsen' : 'ID_fietsen';
            $id = $row[$idField];
            
            
            $table .= "<td>
                <a href='update_fietsen.php?id_fietsen=" . $id . "'>Wijzigen</a>
            </td>";

            $table .= "<td>
                <a href='delete_fietsen.php?id_fietsen=" . $id . "'>Delete</a>
            </td>";

            $table .= "</tr>";
        }
    } else {
        $table .= "<tr><td colspan='100%'>Geen gegevens beschikbaar.</td></tr>";
    }

    $table .= "</table>";

    echo $table;
}

function UpdateFietsen($row) {
    try {
        $conn = ConnectDb();
        $query = $conn->prepare("
            UPDATE fietsenshop 
            SET merk_fietsen = :merk_fietsen,
                type_fietsen = :type_fietsen,
                prijs_fietsen = :prijs_fietsen
            WHERE id_fietsen = :id_fietsen
        ");

        $query->execute([
            ':id_fietsen' => $row['id_fietsen'],
            ':merk_fietsen' => $row['merk_fietsen'],
            ':type_fietsen' => $row['type_fietsen'],
            ':prijs_fietsen' => $row['prijs_fietsen']
        ]);

        echo "Fiets bijgewerkt!";
        return true;
    } catch (Exception $e) {
        echo "Fout bij bijwerken: " . $e->getMessage();
        return false;
    }
}

function GetData($table) {
    $allowedTables = ['fietsenshop']; 

    if (!in_array($table, $allowedTables)) {
        die("Ongeldige tabelnaam.");
    }

    $conn = ConnectDb();
    $query = $conn->prepare("SELECT * FROM $table");
    $query->execute();
    return $query->fetchAll();
}

function ConnectDb() {
    require_once 'configcrudfietsen.php';
    
    try {
        $conn = new PDO($dsn, $user, $pass, $options);
        return $conn;
    } catch (PDOException $e) {
        die("Verbinding mislukt: " . $e->getMessage());
    }
}

function InsertFietsen($post) {
    try {
        $conn = ConnectDb();
    
        $query = $conn->prepare("
            INSERT INTO fietsenshop (merk_fietsen, type_fietsen, prijs_fietsen)
            VALUES (:merk_fietsen, :type_fietsen, :prijs_fietsen)
        ");

        $query->execute([
            ':merk_fietsen' => $post['merk_fietsen'],
            ':type_fietsen' => $post['type_fietsen'],
            ':prijs_fietsen' => $post['prijs_fietsen']
        ]);

        return true;
    
    } catch (PDOException $e) {
        echo "Insert failed: " . $e->getMessage();
        return false;
    }
}

function DeleteFietsen($id) {
    echo "Delete Fietsen<br>";

    try {
        $conn = ConnectDb();
    
        $query = $conn->prepare("
            DELETE FROM fietsenshop 
            WHERE id_fietsen = :id_fietsen");

        return $query->execute([':id_fietsen' => $id]);
    
    } catch (PDOException $e) {
        echo "Delete failed: " . $e->getMessage();
        return false;
    }
}
    
function GetFietsen($id) {

    $conn = ConnectDb();

    $query = $conn->prepare("SELECT * FROM fietsenshop WHERE id_fietsen = :id_fietsen");
    $query->execute([':id_fietsen' => $id]);
    $result = $query->fetch();

    return $result;
}

function GetTypeFiets($id) {
    $conn = ConnectDb();
    $query = $conn->prepare("SELECT * FROM type_fietsen WHERE type_fietsen = :type_fietsen");
    $query->execute([':type_fietsen' => $id]); 
    return $query->fetch();
}

function GetPrijsFiets($id) {
    $conn = ConnectDb();
    $query = $conn->prepare("SELECT * FROM prijs_fietsen WHERE prijs_fietsen = :prijs_fietsen");
    $query->execute([':prijs_fietsen' => $id]); 
    return $query->fetch();
}
?>